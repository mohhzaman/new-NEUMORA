# Updated Alchemy Integration Project

This project integrates Alchemy APIs, including token allowances and transaction simulations, using React and Next.js.

## Setup

1. Clone the repository.
2. Install dependencies: `npm install`.
3. Create a `.env` file with the following:
   ```
   ALCHEMY_API_URL=<your-alchemy-api-url>
   ```
4. Run the project:
   ```
   npm run dev
   ```

## Features

- Fetch token allowances
- Simulate transactions