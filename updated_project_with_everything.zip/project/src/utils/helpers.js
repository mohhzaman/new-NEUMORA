export const formatResponse = (data) => {
  return JSON.stringify(data, null, 2);
};