import React from 'react';

const ExampleComponent = () => <div>Example Component</div>;

export default ExampleComponent;