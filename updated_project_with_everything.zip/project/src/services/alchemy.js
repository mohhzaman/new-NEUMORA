import axios from "axios";

const baseURL = process.env.ALCHEMY_API_URL;

export const getTokenAllowance = async (contract, owner, spender) => {
  try {
    const response = await axios.post(baseURL, {
      jsonrpc: "2.0",
      method: "alchemy_getTokenAllowance",
      id: 1,
      params: [{ contract, owner, spender }]
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching token allowance:", error);
    throw error;
  }
};

export const simulateTransaction = async (from, to, value) => {
  try {
    const response = await axios.post(baseURL, {
      jsonrpc: "2.0",
      method: "alchemy_simulateAssetChanges",
      id: 1,
      params: [{ from, to, value }]
    });
    return response.data;
  } catch (error) {
    console.error("Error simulating transaction:", error);
    throw error;
  }
};