import React, { useState } from "react";
import { getTokenAllowance, simulateTransaction } from "../services/alchemy";

const HomePage = () => {
  const [allowance, setAllowance] = useState(null);
  const [simulationResult, setSimulationResult] = useState(null);

  const fetchTokenAllowance = async () => {
    const result = await getTokenAllowance(
      "0xContractAddress",
      "0xOwnerAddress",
      "0xSpenderAddress"
    );
    setAllowance(result);
  };

  const runSimulation = async () => {
    const result = await simulateTransaction(
      "0xFromAddress",
      "0xToAddress",
      "0xValue"
    );
    setSimulationResult(result);
  };

  return (
    <div>
      <h1>Alchemy Integration</h1>
      <button onClick={fetchTokenAllowance}>Fetch Token Allowance</button>
      <pre>{JSON.stringify(allowance, null, 2)}</pre>

      <button onClick={runSimulation}>Simulate Transaction</button>
      <pre>{JSON.stringify(simulationResult, null, 2)}</pre>
    </div>
  );
};

export default HomePage;